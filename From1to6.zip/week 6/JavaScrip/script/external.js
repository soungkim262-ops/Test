
document.getElementById("es").innerHTML =
"* ខ្លឹមសារធាតុ p ត្រូវបានថែមដោយ external script !";
